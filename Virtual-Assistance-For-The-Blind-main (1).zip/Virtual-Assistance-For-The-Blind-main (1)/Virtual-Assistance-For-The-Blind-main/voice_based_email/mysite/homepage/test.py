import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

def send_email(addr, passwrd, to_addr, subject, body):
    smtp_server = 'smtp.gmail.com'
    smtp_port = 587
    try:
        print(f"Connecting to SMTP server at {smtp_server}:{smtp_port}...")
        server = smtplib.SMTP(smtp_server, smtp_port)
        server.starttls()
        print("Connection established and TLS started.")
        
        print(f"Attempting to log in with email: {addr}")
        server.login(addr, passwrd)
        print("Login successful")
        
        msg = MIMEMultipart()
        msg['From'] = addr
        msg['To'] = to_addr
        msg['Subject'] = subject
        msg.attach(MIMEText(body, 'plain'))
        
        print(f"Sending email to {to_addr}...")
        server.sendmail(addr, to_addr, msg.as_string())
        print("Email sent successfully.")
        
        print("Logging out...")
        server.quit()
        print("Logged out successfully.")
    except smtplib.SMTPAuthenticationError as e:
        print(f"SMTP login failed: {e}")
        print("Ensure that 'Allow less secure apps' is enabled in your Google account settings.")
        print("If you have 2-Step Verification enabled, use an App Password instead of your regular password.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

if __name__ == "__main__":
    addr = 'akshayaksh1421@gmail.com'
    passwrd = 'weji iosc xqqp kuvh'
    to_addr = 'akshayaruku@gmail.com'
    subject = 'hello'
    body = 'how are you'
    send_email(addr, passwrd, to_addr, subject, body)